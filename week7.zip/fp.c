#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
	printf(1,"WOW it really Works\n");
	printf(1,"it is always fun to work with xv6\n");
	exit();
	
}
